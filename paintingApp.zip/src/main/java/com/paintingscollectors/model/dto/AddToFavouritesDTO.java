package com.paintingscollectors.model.dto;

public class AddToFavouritesDTO {
}
