package com.paintingscollectors.model.entity;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "paintings")
public class Painting extends BaseEntity {
    @Column(nullable = false)
    private String name;
    @Column(nullable = false)
    private String author;

    @ManyToOne(optional = false)
    private Style style;
    @ManyToOne
    private User owner;
    @Column(nullable = false, name = "image_url")
    private String imageUrl;
    @ManyToMany
    private Set<User> favourite;
    @ManyToMany
    private Set<User> votes;


    public Painting(){
        this.favourite = new HashSet<>();
        this.votes = new HashSet<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public Style getStyle() {
        return style;
    }

    public void setStyle(Style style) {
        this.style = style;
    }

    public User getOwner() {
        return owner;
    }

    public void setOwner(User owner) {
        this.owner = owner;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Set<User> getFavourite() {
        return favourite;
    }

    public void setFavourite(Set<User> favourite) {
        this.favourite = favourite;
    }

    public Set<User> getVotes() {
        return votes;
    }

    public void setVotes(Set<User> votes) {
        this.votes = votes;
    }
}
