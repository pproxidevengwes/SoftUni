package com.paintingscollectors.model.entity;

public enum StyleType {
    IMPRESSIONISM, ABSTRACT, EXPRESSIONISM, SURREALISM, REALISM
}
