package com.paintingscollectors.controller;

import com.paintingscollectors.config.UserSession;
import com.paintingscollectors.model.entity.Painting;
import com.paintingscollectors.service.PaintingService;
import com.paintingscollectors.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class HomeController {
    public final UserSession userSession;
    private final PaintingService paintingService;
    private final UserService userService;

    public HomeController(UserSession userSession, PaintingService paintingService, UserService userService) {
        this.userSession = userSession;
        this.paintingService = paintingService;
        this.userService = userService;
    }

    @GetMapping("/")
    public String notLoggedIn() {
        if (userSession.isLoggedIn()) {
            return "redirect:/home";
        }
        return "index";
    }

    @GetMapping("/home")
    public String loggedIn(Model model) {
        if (!userSession.isLoggedIn()) {
            return "redirect:/";
        }


        Long userId = userSession.id();

        List<Painting> paintings = paintingService.getPaintingsForUser(userId);
        List<Painting> otherPaintings = paintingService.getPaintingsForOtherUser(userId);

        model.addAttribute("paintings", paintings);
        model.addAttribute("otherPaintings", otherPaintings);

        return "home";
    }

    //    @PostMapping("/remove/{id}")
//    public String removePainting(@PathVariable("id") Long paintingId) {
//        if (!userSession.isLoggedIn()) {
//            return "redirect:/";
//        }
//
//        Long userId = userSession.id();
//        boolean removed = paintingService.removePainting(paintingId, userId);
//        if (!removed) {
//            return "redirect:/";
//        }
//
//        return "redirect:/home";
//    }
//
//    @PostMapping("/add-favorite/{id}")
//    public String addFavorite(@PathVariable Long id) {
//        if (!userSession.isLoggedIn()) {
//            return "redirect:/";
//        }
//        if (this.paintingService.addToFavorites(id, userSession.id())) {
//            return "redirect:/home";
//        }
//
//        return "redirect:/home";
//    }
//
//    @PostMapping("/remove-favorite/{id}")
//    public String removeFavorite(@PathVariable Long id) {
//        if (!userSession.isLoggedIn()) {
//            return "redirect:/";
//        }
//
//        boolean removed = paintingService.removeFromFavorites(id);
//        if (!removed) {
//            return "redirect:/";
//        }
//
//        return "redirect:/home";
//    }
}

