package com.paintingscollectors.service;

import com.paintingscollectors.config.UserSession;
import com.paintingscollectors.model.dto.AddPaintingDTO;
import com.paintingscollectors.model.entity.Painting;
import com.paintingscollectors.model.entity.Style;
import com.paintingscollectors.model.entity.User;
import com.paintingscollectors.repository.PaintingRepository;
import com.paintingscollectors.repository.StyleRepository;
import com.paintingscollectors.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PaintingService {
    private final UserSession userSession;
    private final PaintingRepository paintingRepository;
    private final StyleRepository styleRepository;
    private final UserRepository userRepository;

    public PaintingService(UserSession userSession, PaintingRepository paintingRepository, StyleRepository styleRepository, UserRepository userRepository) {
        this.userSession = userSession;
        this.paintingRepository = paintingRepository;
        this.styleRepository = styleRepository;
        this.userRepository = userRepository;
    }

    public boolean addPainting(AddPaintingDTO paintingDTO) {
        if (!userSession.isLoggedIn()) {
            return false;
        }
        Optional<Style> optionalPainting = this.styleRepository.findByName(paintingDTO.getStyle());

        if (optionalPainting.isEmpty()) {
            return false;
        }

        Optional<User> optionalUser = userRepository.findById(userSession.id());
        if (optionalUser.isEmpty()) {
            return false;
        }

        User currentUser = optionalUser.get();

        Painting painting = new Painting();
        painting.setName(paintingDTO.getName());
        painting.setAuthor(paintingDTO.getAuthor());
        painting.setImageUrl(paintingDTO.getImageUrl());
        painting.setStyle(optionalPainting.get());
        painting.setOwner(currentUser);

        this.paintingRepository.save(painting);


        return true;
    }


    public List<Painting> getPaintingsForUser(Long userId) {
        return this.paintingRepository.findByOwnerId(userId);

    }

    public List<Painting> getPaintingsForOtherUser(Long userId) {
        return this.paintingRepository.findByOwnerIdNot(userId);

    }

    public boolean removePainting(Long paintingId, Long userId) {
        Optional<Painting> optionalPainting = this.paintingRepository.findById(paintingId);

        if (optionalPainting.isEmpty()) {
            return false;
        }

        Painting painting = optionalPainting.get();
        if (painting.getFavourite() != null) {
            return false;
        }

        this.paintingRepository.delete(painting);
        return true;
    }

    public boolean addToFavorites(Long paintingId, Long userId) {
        Optional<Painting> optionalPainting = paintingRepository.findById(paintingId);
        Optional<User> optionalUser = userRepository.findById(userId);

        if (optionalPainting.isPresent() && optionalUser.isPresent()) {
            Painting painting = optionalPainting.get();
            User user = optionalUser.get();

            user.getFavouritePaintings().add(painting);

            userRepository.save(user);

            return true;
        }
        return false;
    }

    public boolean removeFromFavorites(Long paintingId) {
        Optional<Painting> optionalPainting = paintingRepository.findById(paintingId);
        if (optionalPainting.isEmpty()) {
            return false;
        }
        Painting painting = optionalPainting.get();

        if (painting.getFavourite() != null) {
            painting.setFavourite(null);
            paintingRepository.save(painting);
            return true;
        }

        return false;
    }
}
