package com.paintingscollectors.service;

import com.paintingscollectors.config.UserSession;
import com.paintingscollectors.model.dto.UserLoginDTO;
import com.paintingscollectors.model.dto.UserRegisterDTO;
import com.paintingscollectors.model.entity.User;
import com.paintingscollectors.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final UserSession userSession;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder, UserSession userSession) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.userSession = userSession;
    }


    public boolean register(UserRegisterDTO registerDTO) {
        if (!registerDTO.getPassword().equals(registerDTO.getConfirmPassword())) {
            return false; // Passwords don't match
        }
        boolean isUsernameOREmailTaken = userRepository.existsByUsernameOrEmail(registerDTO.getUsername(), registerDTO.getEmail());
        if (isUsernameOREmailTaken) {
            return false; // Username or Email already exists// Username or Email already exists
        }


        User user = new User();
        user.setUsername(registerDTO.getUsername());
        user.setEmail(registerDTO.getEmail());
        user.setPassword(passwordEncoder.encode(registerDTO.getPassword()));

        this.userRepository.save(user);
        return true;
    }


    public boolean login(UserLoginDTO loginDTO) {
        Optional<User> optionalUser = this.userRepository.findByUsername(loginDTO.getUsername());

        if (optionalUser.isEmpty()) {
            return false; // Username not found
        }
        boolean passwordsMatch = this.passwordEncoder.matches(loginDTO.getPassword(), optionalUser.get().getPassword());

        if (!passwordsMatch) {
            return false; // Passwords do not match

        }
        this.userSession.login(optionalUser.get().getId(), loginDTO.getUsername());
        return true;
    }
}

